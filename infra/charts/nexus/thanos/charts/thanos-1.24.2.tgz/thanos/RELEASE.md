
### Fixed

- Use correct component based labels for `HTTPRoute` & `Ingress` resources. ([#1413](https://github.com/stevehipwell/helm-charts/pull/1413)) @stevehipwell
